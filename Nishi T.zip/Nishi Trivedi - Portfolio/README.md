# Portfolio  or Resume or CV
This repo contains a portfolio resume that showcases examples of your work along with the usual resume information about your work experience.
It was created with HTML, CSS and Javascript. Its is lightweight and fully responsive, as well as comes with the Bootstrap.

To view a live demo, [click here](https://bharadhwaj-g.github.io/portfolio/)

## Features
* Easy to integrate
* Fully responsive
* Bootstrap with few animations.

## Setup
* Clone the repository
* Replaced the content with your's info.

## TODO
* Have to setup Gulp or Webpack for minification of script files.
* Make it dynamic
* Provide feature to change the themes or colors easily.

## Changelog

### 1.0.0

* Relesed stable version with basic content
* Added skills section
## License

Completely free (MIT)! See [LICENSE.md](LICENSE.md) for more.